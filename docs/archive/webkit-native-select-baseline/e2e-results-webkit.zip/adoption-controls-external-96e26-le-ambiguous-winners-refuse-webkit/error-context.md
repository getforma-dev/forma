# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: adoption-controls.spec.ts >> external select peers and ordinary implicit defaults remain eligible while ambiguous winners refuse
- Location: e2e/adoption-controls.spec.ts:89:1

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  - 1
+ Received  + 1

@@ -1,10 +1,10 @@
  Object {
    "allDisabled": Array [
      Object {
        "edited": false,
-       "value": true,
+       "value": false,
      },
    ],
    "codes": Array [
      "FORMA_E_HYDRATE_VALUE",
      "FORMA_E_HYDRATE_VALUE",
```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - combobox [ref=e2]:
    - option "one" [selected]
    - option "two"
  - combobox [ref=e3]:
    - option "A"
    - option "B" [selected]
  - combobox [ref=e5]:
    - option "D" [disabled]
    - option "A" [selected]
    - option "B"
  - generic [ref=e6]:
    - listbox [ref=e7]:
      - option "D" [disabled] [ref=e8]
      - option "A" [ref=e9]
    - listbox [ref=e10]:
      - option "D" [disabled] [ref=e11]
      - option "A" [ref=e12]
  - combobox [ref=e14]:
    - option "A" [disabled]
    - option "B" [disabled]
```

# Test source

```ts
  2   | import {build} from 'esbuild';
  3   | import {fileURLToPath} from 'node:url';
  4   | 
  5   | let moduleText='';
  6   | test.beforeAll(async()=>{
  7   |  const result=await build({entryPoints:[fileURLToPath(new URL('../src/dom/adoption-controls.ts',import.meta.url))],bundle:true,write:false,format:'esm',platform:'browser',define:{__FORMA_DEV_BUILD__:'false'},logLevel:'silent'});
  8   |  // This appended helper exists only in the private test module. Keep every
  9   |  // delivered batch, then drain pending records after a macrotask. The separate
  10  |  // positive write happens after the measured read-only phase.
  11  |  moduleText=result.outputFiles[0]!.text+`
  12  |  export function observeMutations() {
  13  |   const records=[];
  14  |   const observer=new MutationObserver(batch=>records.push(...batch));
  15  |   observer.observe(document,{subtree:true,attributes:true,childList:true,characterData:true});
  16  |   return async function finishObservation() {
  17  |    await new Promise(resolve=>setTimeout(resolve,0));
  18  |    records.push(...observer.takeRecords());
  19  |    const mutations=records.length;records.length=0;
  20  |    const target=document.documentElement;
  21  |    target.setAttribute('data-observer-control','present');
  22  |    await new Promise(resolve=>setTimeout(resolve,0));
  23  |    records.push(...observer.takeRecords());observer.disconnect();
  24  |    const positive=records.filter(record=>record.type==='attributes'&&record.target===target&&record.attributeName==='data-observer-control').length;
  25  |    return {mutations,positive};
  26  |   };
  27  |  }
  28  |  `;
  29  | });
  30  | async function serve(page:Page,html:string){
  31  |  await page.route('**/control-kernel.mjs',route=>route.fulfill({contentType:'text/javascript',body:moduleText}));
  32  |  await page.route('**/control-kernel.html',route=>route.fulfill({contentType:'text/html',headers:{'Content-Security-Policy':"default-src 'self'; script-src 'self'; object-src 'none'; require-trusted-types-for 'script'; trusted-types forma-runtime forma-frame"},body:`<!doctype html><html><head></head><body>${html}</body></html>`}));
  33  |  await page.goto('/control-kernel.html');
  34  | }
  35  | test('native radio defaults use form/name groups and last checked winner without writes',async({page})=>{
  36  |  await serve(page,'<form id="f"></form><section id="host"><input id="a" type="radio" name="r" form="f" checked><input id="b" type="radio" name="r" form="f" checked><form><input id="other" type="radio" name="r" checked></form></section><input id="peer" type="radio" name="r" form="f">');
  37  |  const result=await page.evaluate(async()=>{
  38  |   const {AdoptionControls,observeMutations}=await import('/control-kernel.mjs' as string),get=(id:string)=>document.getElementById(id) as HTMLInputElement;
  39  |   const finishObservation=observeMutations();
  40  |   const controls=new AdoptionControls(get('host'));controls.add({element:get('b'),key:'checked',initial:true});controls.add({element:get('a'),key:'checked',initial:true});controls.add({element:get('other'),key:'checked',initial:true});
  41  |   const observed=controls.finish().map(({edited,value}:any)=>({edited,value}));controls.check();const observation=await finishObservation();
  42  |   get('peer').checked=true;let changed='';try{controls.check();}catch(error){changed=(error as any).code;}controls.release();
  43  |   return {observed,...observation,changed};
  44  |  });
  45  |  expect(result).toEqual({observed:[{edited:false,value:true},{edited:false,value:false},{edited:false,value:true}],mutations:0,positive:1,changed:'FORMA_E_HYDRATE_VALUE'});
  46  | });
  47  | test('native sanitized defaults and an early text edit preserve focus selection and setter count',async({page})=>{
  48  |  await serve(page,'<section id="host"><input id="text" value="saved"><input id="range" type="range" min="10" max="20" value="99"><input id="number" type="number" value="7"><input id="color" type="color" value="not-a-color"><input id="mail" type="email" value="  a@example.com  "><textarea id="area">saved notes</textarea></section>');
  49  |  await page.locator('#text').fill('typed before prepare');await page.locator('#text').focus();
  50  |  const result=await page.evaluate(async()=>{
  51  |   const {AdoptionControls,observeMutations}=await import('/control-kernel.mjs' as string),get=(id:string)=>document.getElementById(id) as HTMLInputElement;
  52  |   const input=get('text');input.setSelectionRange(2,7,'backward');let writes=0;
  53  |   const descriptor=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value')!;
  54  |   Object.defineProperty(input,'value',{configurable:true,get(){return descriptor.get!.call(this);},set(value){writes++;descriptor.set!.call(this,value);}});
  55  |   const finishObservation=observeMutations();
  56  |   const controls=new AdoptionControls(get('host'));
  57  |   for(const [id,value]of [['text','saved'],['range',99],['number',7],['color','not-a-color'],['mail','  a@example.com  '],['area','saved notes']] as const)controls.add({element:get(id),key:'value',initial:value,...(id==='text'?{codec:'string'}:{})});
  58  |   const observed=controls.finish().map(({edited,value}:any)=>({edited,value}));controls.check();
  59  |   const observation=await finishObservation();
  60  |   const result={observed,writes,...observation,focus:document.activeElement===input,selection:[input.selectionStart,input.selectionEnd,input.selectionDirection]};controls.release();return result;
  61  |  });
  62  |  expect(result).toEqual({observed:[{edited:true,value:'typed before prepare'},{edited:false,value:'20'},{edited:false,value:'7'},{edited:false,value:'#000000'},{edited:false,value:'a@example.com'},{edited:false,value:'saved notes'}],writes:0,mutations:0,positive:1,focus:true,selection:[2,7,'backward']});
  63  | });
  64  | test('native select normalization preserves default winners and observes ordered multiple edits',async({page})=>{
  65  |  await serve(page,'<section id="host"><select id="single"><optgroup disabled><option value="disabled">D</option></optgroup><option value="a" selected>A</option><option value="a">duplicate A</option><option value="b">B</option></select><select id="multi" multiple><option value="a" selected>A</option><optgroup><option value="b">B</option><option value="c" selected>C</option></optgroup></select><select><option id="bool" value>label</option></select></section>');
  66  |  await page.locator('#multi').selectOption(['b','c']);
  67  |  const result=await page.evaluate(async()=>{
  68  |   const {AdoptionControls,observeMutations}=await import('/control-kernel.mjs' as string),get=(id:string)=>document.getElementById(id)!;
  69  |   const finishObservation=observeMutations();
  70  |   const controls=new AdoptionControls(get('host'));controls.add({element:get('single'),key:'value',initial:'a'});controls.add({element:get('multi'),key:'value',initial:['a','c'],codec:'string-array'});controls.add({element:get('bool'),key:'value',initial:true});
  71  |   const observed=controls.finish().map(({edited,value}:any)=>({edited,value}));controls.check();
  72  |   const result={observed,...await finishObservation(),singleIndex:(get('single') as HTMLSelectElement).selectedIndex,multiDefaults:[...(get('multi') as HTMLSelectElement).options].map(option=>option.defaultSelected)};controls.release();return result;
  73  |  });
  74  |  expect(result).toEqual({observed:[{edited:false,value:'a'},{edited:true,value:['b','c']},{edited:false,value:''}],mutations:0,positive:1,singleIndex:1,multiDefaults:[true,false,true]});
  75  | });
  76  | test('native boolean presence and coded default-before-edit refusal never repair controls',async({page})=>{
  77  |  await serve(page,'<section id="host"><input id="yes" value><input id="no"><input id="nil"><input id="edited" value="server"><input id="wrong" value="server"><input id="n" type="number" value="7"></section>');
  78  |  await page.locator('#edited').fill('user');await page.locator('#n').fill('');
  79  |  const result=await page.evaluate(async()=>{
  80  |   const {AdoptionControls,observeMutations}=await import('/control-kernel.mjs' as string),get=(id:string)=>document.getElementById(id)!;
  81  |   const finishObservation=observeMutations();
  82  |   const untouched=new AdoptionControls(get('host'));for(const [id,initial]of [['yes',true],['no',false],['nil',null]] as const)untouched.add({element:get(id),key:'value',initial});const values=untouched.finish().map(({edited,value}:any)=>({edited,value}));untouched.release();
  83  |   const bad=new AdoptionControls(get('host'));bad.add({element:get('edited'),key:'value',initial:'server'});bad.add({element:get('wrong'),key:'value',initial:'wrong'});let mismatch='';try{bad.finish();}catch(error){mismatch=(error as any).code;}bad.release();
  84  |   const number=new AdoptionControls(get('host'));number.add({element:get('n'),key:'value',initial:7,codec:'number'});let invalid='';try{number.finish();}catch(error){invalid=(error as any).code;}number.release();
  85  |   const result={values,mismatch,invalid,...await finishObservation(),text:(get('edited') as HTMLInputElement).value,number:(get('n') as HTMLInputElement).value};return result;
  86  |  });
  87  |  expect(result).toEqual({values:[{edited:false,value:''},{edited:false,value:''},{edited:false,value:''}],mismatch:'FORMA_E_HYDRATE_VALUE',invalid:'FORMA_E_HYDRATE_INPUT_TARGET',mutations:0,positive:1,text:'user',number:''});
  88  | });
  89  | test('external select peers and ordinary implicit defaults remain eligible while ambiguous winners refuse',async({page,browserName})=>{
  90  |  await serve(page,'<select><option id="plain">one</option><option>two</option></select><select><optgroup id="group"><option id="inside" selected>A</option></optgroup><option id="outside" selected>B</option></select><section id="ambiguous"><select><optgroup disabled><option id="disabled" value="d">D</option></optgroup><option id="enabled" value="a">A</option><option id="unaffected" value="b">B</option></select></section><section id="sized"><select size="2"><optgroup disabled><option value="d">D</option></optgroup><option id="sizeOption" value="a">A</option></select><select multiple><optgroup disabled><option value="d">D</option></optgroup><option id="multipleOption" value="a">A</option></select></section><section id="allDisabled"><select><optgroup disabled><option id="allDisabledFirst">A</option><option>B</option></optgroup></select></section>');
  91  |  const result=await page.evaluate(async()=>{
  92  |   const {AdoptionControls,observeMutations}=await import('/control-kernel.mjs' as string),get=(id:string)=>document.getElementById(id)!;
  93  |   const finishObservation=observeMutations();
  94  |   const plain=new AdoptionControls(get('plain'));plain.add({element:get('plain'),key:'selected',initial:false});const implicit=plain.finish().map(({edited,value}:any)=>({edited,value}));plain.check();plain.release();
  95  |   const group=new AdoptionControls(get('group'));group.add({element:get('inside'),key:'selected',initial:true});const grouped=group.finish().map(({edited,value}:any)=>({edited,value}));group.check();group.release();
  96  |   const codes=[];for(const id of ['disabled','enabled']){const controls=new AdoptionControls(get('ambiguous'));controls.add({element:get(id),key:'selected',initial:false,codec:'boolean'});try{controls.finish();codes.push('PASS');}catch(error){codes.push((error as any).code);}controls.release();}
  97  |   const unaffected=new AdoptionControls(get('ambiguous'));unaffected.add({element:get('unaffected'),key:'selected',initial:false});const other=unaffected.finish().map(({edited,value}:any)=>({edited,value}));unaffected.release();
  98  |   const sized=new AdoptionControls(get('sized'));for(const id of ['sizeOption','multipleOption'])sized.add({element:get(id),key:'selected',initial:false});const noImplicit=sized.finish().map(({edited,value}:any)=>({edited,value}));sized.release();
  99  |   const disabled=new AdoptionControls(get('allDisabled'));disabled.add({element:get('allDisabledFirst'),key:'selected',initial:false});const allDisabled=disabled.finish().map(({edited,value}:any)=>({edited,value}));disabled.release();
  100 |   const result={implicit,grouped,codes,other,noImplicit,allDisabled,...await finishObservation()};return result;
  101 |  });
> 102 |  expect(result).toEqual({implicit:[{edited:false,value:true}],grouped:[{edited:false,value:false}],codes:['FORMA_E_HYDRATE_VALUE','FORMA_E_HYDRATE_VALUE'],other:[{edited:false,value:false}],noImplicit:[{edited:false,value:false},{edited:false,value:false}],allDisabled:[{edited:false,value:browserName==='webkit'}],mutations:0,positive:1});
      |                 ^ Error: expect(received).toEqual(expected) // deep equality
  103 | });
  104 | for(const codec of [undefined,'string'] as const)test(`color alpha/display-p3 defaults stay untouched with ${codec??'readonly'} binding`,async({page})=>{
  105 |  await serve(page,'<section id="host"><input id="i" type="color" alpha colorspace="display-p3" value="color(display-p3 1 0 0 / 0.5)"></section>');
  106 |  const result=await page.evaluate(async codec=>{
  107 |   const {AdoptionControls,observeMutations}=await import('/control-kernel.mjs' as string),input=document.getElementById('i') as HTMLInputElement;
  108 |   const finishObservation=observeMutations(),before=input.value,controls=new AdoptionControls(document.getElementById('host')!);controls.add({element:input,key:'value',initial:'color(display-p3 1 0 0 / 0.5)',codec});
  109 |   const observed=controls.finish().map(({edited,value}:any)=>({edited,value}));controls.check();const observation=await finishObservation();controls.release();return {observed,before,after:input.value,...observation};
  110 |  },codec);
  111 |  expect(result).toEqual({observed:[{edited:false,value:result.before}],before:result.before,after:result.before,mutations:0,positive:1});
  112 | });
  113 | test('literal initialization preserves early control edits without granting reactive seed authority',async({page})=>{
  114 |  await serve(page,'<section id="host"><input id="text" value="saved"><input id="check" type="checkbox" checked><textarea id="area">saved notes</textarea></section>');
  115 |  await page.locator('#text').fill('user text');await page.locator('#check').uncheck();await page.locator('#area').fill('user notes');await page.locator('#area').focus();
  116 |  const result=await page.evaluate(async()=>{
  117 |   const {AdoptionControls,observeMutations}=await import('/control-kernel.mjs' as string),get=(id:string)=>document.getElementById(id)!,area=get('area') as HTMLTextAreaElement;area.setSelectionRange(1,4,'backward');
  118 |   const finishObservation=observeMutations(),controls=new AdoptionControls(get('host'));controls.add({element:get('text'),key:'value',initial:'saved',kind:'initial'});controls.add({element:get('check'),key:'checked',initial:true,kind:'initial'});controls.add({element:area,key:'text',initial:'saved notes',kind:'initial'});
  119 |   const observed=controls.finish().map(({kind,edited,value}:any)=>({kind,edited,value}));controls.check();controls.release();
  120 |   const bad=new AdoptionControls(get('host'));bad.add({element:get('text'),key:'value',initial:'wrong',kind:'initial'});let mismatch='';try{bad.finish();}catch(error){mismatch=(error as any).code;}bad.release();
  121 |   const readonly=new AdoptionControls(get('host'));readonly.add({element:get('text'),key:'value',initial:'saved'});let refused='';try{readonly.finish();}catch(error){refused=(error as any).code;}readonly.release();
  122 |   const observation=await finishObservation();return{observed,mismatch,refused,focus:document.activeElement===area,selection:[area.selectionStart,area.selectionEnd,area.selectionDirection],values:[(get('text') as HTMLInputElement).value,(get('check') as HTMLInputElement).checked,area.value],...observation};
  123 |  });
  124 |  expect(result).toEqual({observed:[{kind:'initial',edited:true,value:'user text'},{kind:'initial',edited:true,value:false},{kind:'initial',edited:true,value:'user notes'}],mismatch:'FORMA_E_HYDRATE_VALUE',refused:'FORMA_E_HYDRATE_INPUT_TARGET',focus:true,selection:[1,4,'backward'],values:['user text',false,'user notes'],mutations:0,positive:1});
  125 | });
  126 | 
```